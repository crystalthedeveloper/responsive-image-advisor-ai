Static assets (images/fonts/etc.) can be added to this directory and referenced from index.html.
