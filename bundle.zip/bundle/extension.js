(() => {
  const SCRIPT_SRC = "https://theme-switcher-app.webflow.io/theme-switcher/theme-switcher.js";
  const MARK_START = "<!-- THEME-SWITCHER-START -->";
  const MARK_END = "<!-- THEME-SWITCHER-END -->";
  const SNIPPET = `
${MARK_START}
<script src="${SCRIPT_SRC}" crossorigin="anonymous"></script>
${MARK_END}
`;
  const DEV_HOST_REGEX = /(?:localhost|127\.0\.0\.1|0\.0\.0\.0)/i;
  const DEV_ENVIRONMENT =
    DEV_HOST_REGEX.test(window.location.hostname || "") ||
    Boolean(window.__WF_EXTENSION_DEV__ || window.__WF_DESIGNER_SCRIPT_DEV__);

  const PANEL_WIDTH = 520;
  const PANEL_HEIGHT = 720;
  const RUNTIME_MAX_ATTEMPTS = 40;
  const RUNTIME_RETRY_DELAY = 300;
  const RUNTIME_TIMEOUT_MS = 15000;
  const DESIGNER_HOST_REGEX = /\.design\.webflow\.com/i;
  const resolveWebflow = () => {
    try {
      if (window.parent && window.parent !== window && window.parent.Webflow) {
        return window.parent.Webflow;
      }
    } catch {
      // Cross-origin access blocked; fall back to local window.
    }
    return window.Webflow;
  };
  const getWebflow = () => resolveWebflow();
  const DESIGNER_PREVIEW_MESSAGE =
    "Theme Switcher injects from Designer. Publish your site and open the live URL to use it.";
  const DESIGNER_API_UNAVAILABLE_MESSAGE =
    "Theme Switcher activates only on published/live sites. Publish and open the live URL to finish enabling.";

  const getRuntimeCandidate = () => window.webflow || window.Webflow || null;
  const createDesignerScriptMock = () => {
    let headCode = "";
    return {
      applyAttributeToSelected: async ({ name, value = "" }) => {
        console.info("[Theme Switcher][DEV MOCK] applyAttributeToSelected", name, value);
        return true;
      },
      getHeadCode: async () => headCode,
      addHeadCode: async (snippet) => {
        headCode = `${headCode}\n${snippet ?? ""}`.trim();
        return true;
      },
      removeHeadCode: async () => {
        headCode = "";
        return true;
      }
    };
  };
  let designerScriptMock = null;
  const getDesignerScriptMock = () => {
    if (!designerScriptMock) {
      designerScriptMock = createDesignerScriptMock();
    }
    return designerScriptMock;
  };

  let runtimePromise = null;
  const getRuntimeApi = () => {
    if (runtimePromise) return runtimePromise;

    runtimePromise = new Promise((resolve, reject) => {
      const immediate = getRuntimeCandidate();
      if (immediate) {
        resolve(immediate);
        return;
      }

      let attempts = 0;
      const startTime = Date.now();
      const timer = setInterval(() => {
        const candidate = getRuntimeCandidate();
        if (candidate) {
          clearInterval(timer);
          resolve(candidate);
          return;
        }

        attempts += 1;
        if (attempts >= RUNTIME_MAX_ATTEMPTS || Date.now() - startTime > RUNTIME_TIMEOUT_MS) {
          clearInterval(timer);
          reject(new Error("Designer runtime unavailable"));
        }
      }, RUNTIME_RETRY_DELAY);
    });

    return runtimePromise;
  };

  const applyFrameSizeStyles = (node, widthPx, heightPx) => {
    if (!node) return;
    node.style.width = widthPx;
    node.style.height = heightPx;
    node.style.minWidth = widthPx;
    node.style.minHeight = heightPx;
  };

  const enforceFrameSize = (size) => {
    const frame = window.frameElement;
    const widthPx = `${size.width}px`;
    const heightPx = `${size.height}px`;
    applyFrameSizeStyles(frame, widthPx, heightPx);
    applyFrameSizeStyles(frame?.parentElement, widthPx, heightPx);
  };

  const requestPanelSize = (api, size) => {
    try {
      if (typeof api.setExtensionSize === "function") {
        const result = api.setExtensionSize(size);
        if (result && typeof result.then === "function") {
          result.catch(() => {});
        }
        enforceFrameSize(size);
        return true;
      }
      if (typeof api.resize === "function") {
        api.resize(size);
        enforceFrameSize(size);
        return true;
      }
    } catch {
      enforceFrameSize(size);
    }
    return false;
  };

  const ensureResize = () => {
    const size = { width: PANEL_WIDTH, height: PANEL_HEIGHT };
    getRuntimeApi()
      .then((api) => {
        if (!requestPanelSize(api, size)) {
          enforceFrameSize(size);
        }
      })
      .catch(() => enforceFrameSize(size));

    let attempts = 0;
    const timer = setInterval(() => {
      attempts += 1;
      getRuntimeApi()
        .then((api) => {
          if (requestPanelSize(api, size)) {
            clearInterval(timer);
          } else if (attempts >= RUNTIME_MAX_ATTEMPTS) {
            clearInterval(timer);
          }
        })
        .catch(() => {
          if (attempts >= RUNTIME_MAX_ATTEMPTS) {
            clearInterval(timer);
          }
        });
    }, RUNTIME_RETRY_DELAY);
  };

  ensureResize();
  const isDesignerPreview = DESIGNER_HOST_REGEX.test(document.referrer || "");

  let designerScriptPromise = null;
  const loadDesignerScriptApi = () => {
    const wf = getWebflow();
    if (!wf?.require) return Promise.resolve(null);
    if (designerScriptPromise) return designerScriptPromise;

    designerScriptPromise = new Promise((resolve, reject) => {
      try {
        const module = wf.require("designerscript");
        if (module?.then) {
          module.then(resolve).catch(reject);
        } else {
          resolve(module);
        }
      } catch (err) {
        reject(err);
      }
    })
      .then((api) => {
        if (!api) {
          designerScriptPromise = null;
        }
        return api;
      })
      .catch(() => {
        designerScriptPromise = null;
        return null;
      });

    return designerScriptPromise;
  };

  const resolveDesignerScriptApi = () => {
    if (DEV_ENVIRONMENT) {
      return Promise.resolve(getDesignerScriptMock());
    }
    return loadDesignerScriptApi();
  };


  const initReadOnlyPreview = () => {
    const showPreviewMessage = () => {
      setStatus(DESIGNER_PREVIEW_MESSAGE);
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", showPreviewMessage, { once: true });
    } else {
      showPreviewMessage();
    }
  };

  const setStatus = (msg) => {
    const el = document.getElementById("status");
    if (el) el.textContent = msg;
  };

  const showDesignerUnavailableNotice = () => {
    if (isDesignerPreview) {
      setStatus(DESIGNER_PREVIEW_MESSAGE);
    } else {
      setStatus(DESIGNER_API_UNAVAILABLE_MESSAGE);
    }
  };

  const includesSnippet = (code) => {
    if (!code) return false;
    return code.includes(SCRIPT_SRC) || code.includes(MARK_START);
  };

  const markInstalledStatus = () => {
    setStatus("✅ Theme Switcher installed. Publish and open your live site to use it.");
  };
  const markUninstalledStatus = () => {
    setStatus("Theme Switcher is not installed. Unable to inject script into site head.");
  };

  const installWithManager = async (manager) => {
    if (!manager) return false;
    let currentHead = "";
    try {
      currentHead = (await manager.getHeadCode?.()) ?? "";
    } catch {
      currentHead = "";
    }

    if (includesSnippet(currentHead)) {
      markInstalledStatus();
      return true;
    }

    try {
      if (typeof manager.removeHeadCode === "function") {
        try {
          await manager.removeHeadCode({ start: MARK_START, end: MARK_END });
        } catch {
          // ignore removal failure
        }
      }
      await manager.addHeadCode(SNIPPET);
      markInstalledStatus();
      return true;
    } catch {
      return false;
    }
  };

  const resolveAttributeApi = async () => {
    const designerApi = await resolveDesignerScriptApi().catch(() => null);
    if (designerApi?.applyAttributeToSelected) return designerApi;
    const runtime = await getRuntimeApi().catch(() => null);
    if (runtime?.applyAttributeToSelected) return runtime;
    if (runtime?.designerScript?.applyAttributeToSelected) return runtime.designerScript;
    if (runtime?.designerscript?.applyAttributeToSelected) return runtime.designerscript;
    return null;
  };

  const applySelectedAttributes = async (attributes = []) => {
    if (!attributes.length) return;
    const api = await resolveAttributeApi();
    if (!api) {
      showDesignerUnavailableNotice();
      return;
    }
    try {
      await Promise.all(
        attributes.map(({ name, value = "" }) =>
          api.applyAttributeToSelected({ name, value: value ?? "" })
        )
      );
      setStatus(`Applied: ${attributes.map((attr) => attr.name).join(", ")}`);
    } catch (err) {
      showDesignerUnavailableNotice();
    }
  };

  const resolveHeadCodeManager = async () => {
    const designer = await resolveDesignerScriptApi().catch(() => null);
    if (
      designer &&
      (typeof designer.addHeadCode === "function" ||
        typeof designer.getHeadCode === "function" ||
        typeof designer.removeHeadCode === "function")
    ) {
      return designer;
    }

    const runtime = await getRuntimeApi().catch(() => null);
    if (!runtime) return null;
    const manager =
      runtime.customCode ||
      runtime.headCode ||
      runtime.code ||
      runtime.designerScript ||
      runtime.designerscript ||
      runtime;

    if (
      manager &&
      (typeof manager.addHeadCode === "function" ||
        typeof manager.getHeadCode === "function" ||
        typeof manager.removeHeadCode === "function")
    ) {
      return manager;
    }
    return null;
  };

  const initAttributeTools = () => {
    const buttons = document.querySelectorAll('[data-attr-action="apply"]');
    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const { attrName, attrValue } = btn.dataset;
        if (!attrName) return;
        applySelectedAttributes([{ name: attrName, value: attrValue ?? "" }]);
      });
    });

    const advancedConfigs = [
      {
        buttonId: "apply-theme-text",
        baseAttr: "data-cltd-theme-text",
        darkInput: "input-theme-text-dark",
        lightInput: "input-theme-text-light",
      },
      {
        buttonId: "apply-theme-bg",
        baseAttr: "data-cltd-theme-bg",
        darkInput: "input-theme-bg-dark",
        lightInput: "input-theme-bg-light",
      },
      {
        buttonId: "apply-theme-link",
        baseAttr: "data-cltd-theme-link",
        darkInput: "input-theme-link-dark",
        lightInput: "input-theme-link-light",
      },
    ];

    advancedConfigs.forEach((cfg) => {
      const button = document.getElementById(cfg.buttonId);
      if (!button) return;
      button.addEventListener("click", () => {
        const darkValue = (document.getElementById(cfg.darkInput)?.value || "").trim();
        const lightValue = (document.getElementById(cfg.lightInput)?.value || "").trim();
        const attributes = [{ name: cfg.baseAttr, value: "" }];
        if (darkValue) attributes.push({ name: "data-cltd-dark", value: darkValue });
        if (lightValue) attributes.push({ name: "data-cltd-light", value: lightValue });
        applySelectedAttributes(attributes);
      });
    });
  };

  const inject = async () => {
    const manager = await resolveHeadCodeManager();
    if (!manager) {
      showDesignerUnavailableNotice();
      return false;
    }

    const success = await installWithManager(manager);
    if (!success) showDesignerUnavailableNotice();
    return success;
  };

  let installTriggered = false;
  const ensureAutomaticInstall = () => {
    if (installTriggered) return;
    installTriggered = true;

    const wfApi = getWebflow();
    if (!wfApi?.push) {
      inject();
      return;
    }

    wfApi.push(async () => {
      try {
        const designer = await loadDesignerScriptApi();
        if (!designer) {
          markUninstalledStatus();
          return;
        }
        // Ensure only one instance of the script exists.
        if (typeof designer.removeHeadCode === "function") {
          try {
            await designer.removeHeadCode({ start: MARK_START, end: MARK_END });
          } catch {
            // best effort cleanup
          }
        }
        await designer.addHeadCode(SNIPPET);
        const updatedHead = (await designer.getHeadCode?.()) ?? "";
        if (includesSnippet(updatedHead)) {
          markInstalledStatus();
        } else {
          markUninstalledStatus();
        }
      } catch {
        markUninstalledStatus();
      }
    });
  };

  let initialized = false;

  const init = () => {
    if (initialized) return;
    initialized = true;
    initAttributeTools();
  };

  const startWhenReady = () => {
    ensureAutomaticInstall();
    if (isDesignerPreview) {
      initReadOnlyPreview();
    }

    const boot = () => {
      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => init(), { once: true });
      } else {
        init();
      }
    };

    const wfApi = getWebflow();
    if (wfApi?.push) {
      wfApi.push(boot);
    } else {
      boot();
    }
  };

  startWhenReady();
})();
